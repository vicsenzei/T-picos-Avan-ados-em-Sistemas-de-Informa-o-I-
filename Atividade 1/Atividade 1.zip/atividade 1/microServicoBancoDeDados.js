module.exports =  function microServicoBD(){
    // var executando = 
    return "--> Micro serviço de bando de dados";
};
