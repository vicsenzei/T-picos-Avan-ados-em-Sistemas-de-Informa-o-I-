module.exports = function microServicoClientes(){
    return "--> Micro serviço de clientes";
};