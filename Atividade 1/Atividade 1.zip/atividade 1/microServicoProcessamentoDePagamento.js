module.exports = function microServicoPagamentos(){
    return "--> Micro serviço de processamento de pagamentos";
}